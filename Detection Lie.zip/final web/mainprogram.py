from flask import Flask, render_template, Response
import cv2

app = Flask (__name__)

@app.route('/')
@app.route('/index.html')
def home():
    return render_template('index.html')

@app.route('/detected.html')
def detection():
    return render_template('detected.html')

def cam():
    cari_wajah = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    cari_mata = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
    video_capture = cv2.VideoCapture(r'C:\Users\acer\Pictures\asti.mp4')
    
    while (video_capture.isOpened()):
        ret, img = video_capture.read()
        if ret == True:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            wajah = cari_wajah.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=10, minSize=(80, 80))
            for (x, y, w, h) in wajah:
                cv2.rectangle(img, (x,y), (x+w, y+h), (0, 255, 0), 2)
                eye_gray = gray[y:y+w, x:x+w]
                eye_color = img[y:y+h, x:x+w]
                eyes = cari_mata.detectMultiScale(eye_gray, scaleFactor=1.1, minNeighbors=5)
                for(ex, ey, ew, eh) in eyes:
                    cv2.rectangle(eye_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0),1)
            flip = cv2.flip(img, 1)
            frame = cv2.imencode('.jpg', flip)[1].tobytes()
            yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            break

@app.route('/video_feed')
def video_feed():
    return Response(cam(), mimetype='multipart/x-mixed-replace; boundary=frame')



app.run(debug=True)